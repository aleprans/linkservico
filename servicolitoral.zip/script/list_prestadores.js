var term = queryString("term")
let anunciantes

setInterval(function(){ 
    anuncios_r()
    anuncios_l()
    anuncios_f()
    ; }, 5000);



$(document).ready(function(){
    busca_anunciantes()
    busca_prestador()
    
})

function busca_anunciantes(){
    $.ajax({
        url: 'api.php',
        type: 'post',
        dataType: 'json',
        cache: false,
        data: {action: 'anunciantes'},
        success:function(json){
            if(json.status) {
                anunciantes = json.anunciantes
                anuncios_r()
                anuncios_l()
                anuncios_f()
            }
        }
    })
}

function busca_prestador(){
    alert(term.length)
    if(term.length > 0){
        $.ajax({
            url: 'api.php',
            type: 'post',
            dataType: 'json',
            data: {
                term: term,
                action: 'buscar_prestadores_palavra'
            },
            success:function(json){
                if(json.status){
                    let prestadores = ""
                    for (let i = 0; i < json.data.length; i++){
                        let prest = '<div class="prestadores">'+
                        '<p>'+json.data[i].pr_nome+'</p>'+
                        '</div>'
                        prestadores = prestadores + prest
                    }
                    document.getElementById('list_prestadores').innerHTML = prestadores
                }
            }
        })
    }else {
        alert(term)
    }
}
