<?php

session_start();

include_once('connect.php');


$action = mysqli_real_escape_string($connect, $_POST['action']);

switch ($action) {
    case 'logar':
        $user = mysqli_real_escape_string($connect, $_POST['user']);
        $pass = mysqli_real_escape_string($connect, $_POST['pass']);
        $sql = "SELECT * 
            FROM prestadores 
            where (pr_usuario = '{$user}' OR pr_cpf = '{$user}') 
            AND pr_senha = '{$pass}'";
        $result = mysqli_query($connect, $sql);
        $rows = mysqli_num_rows($result);
        $data = mysqli_fetch_all ($result, MYSQLI_ASSOC);

        if ($rows > 0){
            $_SESSION['usuario'] = $data[0]['pr_usuario'];
            $_SESSION['cpf'] = $data[0]['pr_cpf'];
            echo json_encode(['status' => true, 'msg' => 'Logado com Sucesso!']);
            mysqli_close($connect);
            exit;
        }else {
            echo json_encode(['status' => false, 'msg' => 'Usuário e/ou senha inválidos!']);
            mysqli_close($connect);
            exit;
        }
    break;
    
    case 'buscar_bairros':
        $term = mysqli_real_escape_string($connect, $_POST['cidade']);
        $sql = "SELECT id_bairro, ba_descricao FROM bairros WHERE ba_cidade = '{$term}' order by ba_descricao";
        $result = mysqli_query($connect, $sql);
       
        $data = mysqli_fetch_all ($result, MYSQLI_ASSOC);

        echo json_encode(['status' => true, 'data' => $data]);
        mysqli_close($connect);
        exit;
    break;
        
    case 'cad_prestador':
        $nome = $_POST['nome'];
        $usuario = $_POST['usuario'];
        $cpf = preg_replace('/[^0-9]/', '',$_POST['prestador']);
        $email = $_POST['email'];
        $senha = "";
        $in_senha = "";
        if(isset($_POST['senha'])){
            $senha = $_POST['senha'];
            $in_senha = 'pr_senha = ';
        }
        $telefone = preg_replace('/[^0-9]/', '',$_POST['telefone']);
        $cidade = $_POST['cidade'];
        $bairro = $_POST['bairro'];
        $categoria = $_POST['categoria'];
        $descricao = $_POST['descricao'];
        if(isset($_POST['usuario'])){
            $sql = "UPDATE prestadores
                SET 
                    pr_usuario = '$usuario',
                    {$in_senha}{$senha}
                    pr_bairro = '$bairro', 
                    pr_cidade = '$cidade', 
                    pr_telefone = '$telefone', 
                    pr_nome = '$nome', 
                    pr_cpf = '$cpf', 
                    pr_categoria = '$categoria', 
                    pr_descricao = '$descricao', 
                    pr_email = '$email'
                WHERE cpf = $cpf";
        }else {
            $sql = "INSERT INTO prestadores (
                pr_usuario, 
                pr_senha,
                pr_bairro, 
                pr_cidade, 
                pr_telefone, 
                pr_nome, 
                pr_cpf, 
                pr_categoria, 
                pr_descricao, 
                pr_email)
                VALUES (
                '$usuario',
                '$senha',
                '$bairro', 
                '$cidade', 
                '$telefone', 
                '$nome', 
                '$cpf', 
                '$categoria', 
                '$descricao',
                '$email'
                )";
        }
        
        $result = mysqli_query($connect, $sql);
        if($result){
            
            if (!empty($_FILES)) {
                /*Arquivo está sendo enviado para pasta image/prestadores */
                for($i = 0; $i < count($_FILES); $i++){
                    $diretorio = "image/prestadores/".$_POST['prestador']."/";
                    if(!is_dir($diretorio)){
                        mkdir($diretorio);
                    }
                    
                    $move_upload_rs = move_uploaded_file($_FILES[$i]['tmp_name'], "image/prestadores/".$_POST['prestador']."/".$_FILES[$i]['name']);
                }
                if($move_upload_rs){
                    $connect->commit();
                    echo json_encode(['status' => true, 'msg' => 'Dados salvos com sucesso!']);
                    exit;
                }else {
                    $connect->rollback();
                    echo json_encode(['status' => false, 'msg' => 'Falha ao salvar arquivos!']);
                    exit;
                }
            }
            $connect->commit();
            echo json_encode(['status' => true, 'msg' => 'Dados salvos com sucesso!']);
            exit;
        }else{
            $connect->rollback();
            echo json_encode(['status' => false, 'msg' => 'Falha ao salvar os Dados!']);
            exit;
        }
        $connect->close();
    break;

    case 'buscar_prestador':
        $usu = $_POST['usuario'];
        $sql = "SELECT
            * FROM
                prestadores
            WHERE
                pr_cpf = $usu
            ";
        $result = mysqli_query($connect, $sql);
        $data = mysqli_fetch_all($result, MYSQLI_ASSOC);

        if($data){
            $arquivos[] = scandir("./image/prestadores/".$usu."/");

            echo(json_encode(['status'=> true, 'data'=> $data, 'files'=> $arquivos]));
        }

    break;

    case 'buscar_prestadores_palavra':
        $term = $_POST['term'];

        $sql = "SELECT 
                    pr.pr_cpf cpf,
                    pr.pr_nome nome, 
                    pr.pr_descricao descricao, 
                    pr.pr_email email, 
                    pr.pr_telefone telefone, 
                    cat.cat_descricao categoria
                FROM 
                    prestadores pr 
                left join 
                    categorias cat 
                on 
                    pr.pr_categoria = cat.id_categoria 
                WHERE pr_descricao LIKE '%$term%'
                    OR pr_nome LIKE '%$term%'
                    OR cat.cat_descricao LIKE '%$term%'
                ";
        $result = mysqli_query($connect, $sql);

        $data = mysqli_fetch_all ($result, MYSQLI_ASSOC);
        if($data){
            for($i = 0; $i < count($data); $i++){
                
                $dir = $data[$i]['cpf'];
                if(is_dir("./image/prestadores/".$dir."/")){

                    $arquivos[$i] = scandir("./image/prestadores/".$dir."/"); 
                }
            }
            echo json_encode(['status'=> true, 'data' => $data, 'imagens' => $arquivos]);
        }else{
            echo json_encode(['status'=>false, 'msg'=>'Não há prestadores para a opção escolida!']);
        }
    break;
        
    case 'anunciantes':
        $sql = "SELECT an_cnpj FROM anunciantes where status = 'A'";
        $result = mysqli_query($connect, $sql);
        
        $data = mysqli_fetch_all ($result, MYSQLI_ASSOC);

        echo json_encode(['status'=> true, 'anunciantes'=>$data]);

    break;

    default:
        echo json_encode(['status'=> false, 'msg' => 'Ação não encontrada']);
    break;
}

?>